﻿namespace Model
{
    public class Endereco // Corrigido: Address (não Adress)
    {
        public int Id { get; set; }
        public string? Street1 { get; set; }
        public string? Street2 { get; set; }
        public string? City { get; set; }
        public string? State_Province { get; set; }
        public string? Postal_Code { get; set; }
        public string? Country { get; set; }
        public string? Address_Type { get; set; } // Corrigido: Address_Type (não Adress_Type)

        public bool Validate()
        {
            bool isValid = true;
            isValid =
                (this.Id > 0) &&
                !string.IsNullOrEmpty(this.Street1) &&
                !string.IsNullOrEmpty(this.City) &&
                !string.IsNullOrEmpty(this.State_Province) &&
                !string.IsNullOrEmpty(this.Country);
            return isValid;
        }

        // Método para retornar endereço formatado
        public string GetFormattedAddress()
        {
            var parts = new List<string>();

            if (!string.IsNullOrEmpty(Street1))
                parts.Add(Street1);

            if (!string.IsNullOrEmpty(Street2))
                parts.Add(Street2);

            if (!string.IsNullOrEmpty(City))
                parts.Add(City);

            if (!string.IsNullOrEmpty(State_Province))
                parts.Add(State_Province);

            if (!string.IsNullOrEmpty(Postal_Code))
                parts.Add($"CEP: {Postal_Code}");

            if (!string.IsNullOrEmpty(Country))
                parts.Add(Country);

            return string.Join(", ", parts);
        }

        // Método para endereço resumido (uma linha)
        public string GetShortAddress()
        {
            return $"{Street1}, {City} - {State_Province}";
        }
    }
}