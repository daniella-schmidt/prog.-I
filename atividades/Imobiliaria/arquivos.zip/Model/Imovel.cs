﻿namespace Model
{
    public class Imovel
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Descricao { get; set; }
        public int NumeroQuartos { get; set; }
        public int NumeroVagasGaragem { get; set; }
        public int NumeroBanheiros { get; set; }
        public Endereco? Endereco { get; set; }
        public Categoria? Categoria { get; set; }
        public decimal Valor { get; set; }
        public bool ParaVenda { get; set; } = true;

        public List<Cliente>? ClientesInteressados { get; set; } = new List<Cliente>();
        public Cliente? ClienteAdquirente { get; set; }
        public DateTime? DataInteresse { get; set; }
        public DateTime? DataVendaLocacao { get; set; }
        public bool VendidoAlugado { get; set; }

        public bool Validate()
        {
            bool isValid = true;
            isValid =
                (this.Id > 0) &&
                !string.IsNullOrEmpty(this.Nome) &&
                (this.NumeroQuartos >= 0) &&
                (this.NumeroVagasGaragem >= 0) &&
                (this.NumeroBanheiros >= 0) &&
                (this.Endereco != null) &&
                (this.Categoria != null) &&
                (this.Valor > 0);
            return isValid;
        }

        // Método para exportar dados do imóvel em formato delimitado
        public string ToDelimitedString(string delimiter = ";")
        {
            return $"{Id}{delimiter}" +
                   $"{Nome}{delimiter}" +
                   $"{Descricao}{delimiter}" +
                   $"{NumeroQuartos}{delimiter}" +
                   $"{NumeroVagasGaragem}{delimiter}" +
                   $"{NumeroBanheiros}{delimiter}" +
                   $"{Endereco?.Street1} {Endereco?.Street2}, {Endereco?.City}, {Endereco?.State_Province}{delimiter}" +
                   $"{Categoria?.Nome}{delimiter}" +
                   $"{Valor:C}{delimiter}" +
                   $"{(ParaVenda ? "Venda" : "Locação")}";
        }
    }
}