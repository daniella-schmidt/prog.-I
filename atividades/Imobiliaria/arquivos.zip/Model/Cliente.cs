﻿namespace Model
{
    public class Cliente
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Email { get; set; }
        public string? Telefone { get; set; }
        public string? CPF { get; set; }
        public List<Imovel>? ImoveisInteresse { get; set; } = new List<Imovel>(); // Imóveis de interesse (aluguel/compra)

        public bool Validate()
        {
            return
                Id > 0 &&
                !string.IsNullOrEmpty(Nome) &&
                !string.IsNullOrEmpty(Email) &&
                !string.IsNullOrEmpty(Telefone) &&
                !string.IsNullOrEmpty(CPF);
        }

        // Método para exportar dados em formato delimitado
        public string ToDelimitedString(string delimiter = ";")
        {
            return $"{Id}{delimiter}" +
                   $"{Nome}{delimiter}" +
                   $"{Email}{delimiter}" +
                   $"{Telefone}{delimiter}" +
                   $"{CPF}{delimiter}" +
                   $"Interesses: {ImoveisInteresse?.Count ?? 0}";
        }
    }
}