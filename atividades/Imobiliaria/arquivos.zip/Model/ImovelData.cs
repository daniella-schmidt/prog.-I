﻿using Model;
using System.Collections.Generic;

namespace Repository
{
    public static class ImovelData
    {
        public static List<Imovel> Imoveis { get; set; } = new List<Imovel>();
        public static List<Categoria> Categorias { get; set; } = new List<Categoria>();
    }
}