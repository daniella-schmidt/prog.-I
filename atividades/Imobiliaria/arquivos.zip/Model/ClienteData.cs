﻿namespace Model
{
    public static class ClienteData
    {
        public static List<Cliente> Clientes = new List<Cliente>();
    }
}