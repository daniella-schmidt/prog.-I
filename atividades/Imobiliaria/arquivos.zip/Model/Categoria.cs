﻿namespace Model
{
    public class Categoria
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Descricao { get; set; }

        public bool Validate()
        {
            bool isValid = true;
            isValid =
                (this.Id > 0) &&
                !string.IsNullOrEmpty(this.Nome);
            return isValid;
        }
    }
}