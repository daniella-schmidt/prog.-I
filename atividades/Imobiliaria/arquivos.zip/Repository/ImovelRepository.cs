﻿using Model;
using System.Text;

namespace Repository
{
    public class ImovelRepository
    {
        // Acessa a lista estática de ImovelData
        public List<Imovel> _imoveis => ImovelData.Imoveis;

        public Imovel Retrieve(int id)
        {
            return _imoveis.FirstOrDefault(i => i.Id == id)!;
        }

        public List<Imovel> RetrieveByName(string nome)
        {
            return _imoveis
                .Where(i => i.Nome?.ToLower().Contains(nome.ToLower()) ?? false)
                .ToList();
        }

        public List<Imovel> RetrieveByCategoria(int categoriaId)
        {
            return _imoveis
                .Where(i => i.Categoria?.Id == categoriaId)
                .ToList();
        }

        public List<Imovel> RetrieveByTipo(bool paraVenda)
        {
            return _imoveis
                .Where(i => i.ParaVenda == paraVenda)
                .ToList();
        }

        public List<Imovel> RetrieveAll()
        {
            return _imoveis;
        }

        public void Save(Imovel imovel)
        {
            imovel.Id = GetCount() + 1;
            _imoveis.Add(imovel);
        }

        public bool Delete(Imovel imovel)
        {
            return _imoveis.Remove(imovel);
        }

        public bool DeleteById(int id)
        {
            var imovel = Retrieve(id);
            return imovel != null && Delete(imovel);
        }

        public void Update(Imovel newImovel)
        {
            var oldImovel = Retrieve(newImovel.Id);
            if (oldImovel != null)
            {
                oldImovel.Nome = newImovel.Nome;
                oldImovel.Descricao = newImovel.Descricao;
                oldImovel.NumeroQuartos = newImovel.NumeroQuartos;
                oldImovel.NumeroVagasGaragem = newImovel.NumeroVagasGaragem;
                oldImovel.NumeroBanheiros = newImovel.NumeroBanheiros;
                oldImovel.Endereco = newImovel.Endereco;
                oldImovel.Categoria = newImovel.Categoria;
                oldImovel.Valor = newImovel.Valor;
                oldImovel.ParaVenda = newImovel.ParaVenda;
            }
        }

        public int GetCount() => _imoveis.Count;

        public Dictionary<string, int> GetStatistics()
        {
            var stats = new Dictionary<string, int>();

            stats["Total"] = _imoveis.Count;
            stats["Para Venda"] = _imoveis.Count(i => i.ParaVenda);
            stats["Para Locação"] = _imoveis.Count(i => !i.ParaVenda);

            // Estatísticas por categoria
            foreach (var categoria in ImovelData.Categorias)
            {
                stats[$"Categoria: {categoria.Nome}"] = _imoveis.Count(i => i.Categoria?.Id == categoria.Id);
            }

            return stats;
        }

        public void AdicionarInteresseCliente(int imovelId, int clienteId)
        {
            var imovel = Retrieve(imovelId);
            var cliente = new ClienteRepository().Retrieve(clienteId);

            if (imovel != null && cliente != null)
            {
                imovel.ClientesInteressados ??= new List<Cliente>();
                if (!imovel.ClientesInteressados.Any(c => c.Id == clienteId))
                {
                    imovel.ClientesInteressados.Add(cliente);
                    imovel.DataInteresse = DateTime.Now;
                }
            }
        }

        public void RegistrarVendaLocacao(int imovelId, int clienteId, bool vendido)
        {
            var imovel = Retrieve(imovelId);
            var cliente = new ClienteRepository().Retrieve(clienteId);

            if (imovel != null && cliente != null)
            {
                imovel.ClienteAdquirente = cliente;
                imovel.VendidoAlugado = vendido;
                imovel.DataVendaLocacao = DateTime.Now;

                // Remove de interessados se estiver lá
                imovel.ClientesInteressados?.RemoveAll(c => c.Id == clienteId);
            }
        }
    }
}