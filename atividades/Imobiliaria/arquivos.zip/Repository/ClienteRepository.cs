﻿using Model;
using System.Collections.Generic;
using System.Linq;

namespace Repository
{
    public class ClienteRepository
    {
        public List<Cliente> _customers => ClienteData.Clientes;

        public Cliente Retrieve(int id)
        {
            return _customers.FirstOrDefault(c => c.Id == id)!;
        }

        public List<Cliente> RetrieveByName(string nome)
        {
            return _customers
                .Where(c => c.Nome?.ToLower().Contains(nome.ToLower()) ?? false)
                .ToList();
        }

        public List<Cliente> RetrieveByEmail(string email)
        {
            return _customers
                .Where(c => c.Email?.ToLower().Contains(email.ToLower()) ?? false)
                .ToList();
        }

        public List<Cliente> RetrieveAll()
        {
            return _customers;
        }

        public void Save(Cliente customer)
        {
            customer.Id = _customers.Count + 1;
            _customers.Add(customer);
        }

        public bool Delete(Cliente customer)
        {
            return _customers.Remove(customer);
        }

        public bool DeleteById(int id)
        {
            var customer = Retrieve(id);
            return customer != null && Delete(customer);
        }

        public void Update(Cliente updatedCliente)
        {
            var existingCliente = Retrieve(updatedCliente.Id);
            if (existingCliente != null)
            {
                existingCliente.Nome = updatedCliente.Nome;
                existingCliente.Email = updatedCliente.Email;
                existingCliente.Telefone = updatedCliente.Telefone;
                existingCliente.CPF = updatedCliente.CPF;
                existingCliente.ImoveisInteresse = updatedCliente.ImoveisInteresse;
            }
        }

        public void AdicionarInteresse(int customerId, int imovelId)
        {
            var customer = Retrieve(customerId);
            var imovel = new ImovelRepository().Retrieve(imovelId);

            if (customer != null && imovel != null)
            {
                customer.ImoveisInteresse ??= new List<Imovel>();
                customer.ImoveisInteresse.Add(imovel);
            }
        }

        public Dictionary<string, int> GetStatistics()
        {
            return new Dictionary<string, int>
            {
                { "Total Clientes", _customers.Count },
                { "Clientes com Interesses", _customers.Count(c => c.ImoveisInteresse?.Count > 0) }
            };
        }
    }
}