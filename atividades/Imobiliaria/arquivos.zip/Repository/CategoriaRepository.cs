﻿using Model;

namespace Repository
{
    public class CategoriaRepository
    {
        public CategoriaRepository()
        {
            ImovelData.Categorias ??= new List<Categoria>();
        }

        public Categoria Retrieve(int id)
        {
            foreach (Categoria c in ImovelData.Categorias)
            {
                if (c.Id == id)
                    return c;
            }
            return null!;
        }

        public List<Categoria> RetrieveByName(string nome)
        {
            List<Categoria> ret = new List<Categoria>();

            foreach (Categoria c in ImovelData.Categorias)
            {
                if (c.Nome!.ToLower().Contains(nome.ToLower()))
                {
                    ret.Add(c);
                }
            }
            return ret;
        }

        public List<Categoria> RetrieveAll()
        {
            return ImovelData.Categorias;
        }

        public void Save(Categoria categoria)
        {
            categoria.Id = GetCount() + 1;
            ImovelData.Categorias.Add(categoria);
        }

        public bool Delete(Categoria categoria)
        {
            return ImovelData.Categorias.Remove(categoria);
        }

        public bool DeleteById(int id)
        {
            Categoria categoria = Retrieve(id);
            if (categoria != null)
                return Delete(categoria);
            return false;
        }

        public void Update(Categoria newCategoria)
        {
            Categoria oldCategoria = Retrieve(newCategoria.Id);
            if (oldCategoria != null)
            {
                oldCategoria.Nome = newCategoria.Nome;
                oldCategoria.Descricao = newCategoria.Descricao;
            }
        }

        public int GetCount()
        {
            return ImovelData.Categorias.Count;
        }

        // Método para inicializar categorias padrão
        public void InitializeDefaultCategories()
        {
            if (ImovelData.Categorias.Count == 0)
            {
                // Usar Save para garantir que os IDs são gerados corretamente
                Save(new Categoria { Nome = "Apartamento", Descricao = "Unidade residencial em edifício" });
                Save(new Categoria { Nome = "Casa", Descricao = "Residência térrea ou sobrado" });
                Save(new Categoria { Nome = "Sítio", Descricao = "Propriedade rural para lazer" });
                Save(new Categoria { Nome = "Sala Comercial", Descricao = "Espaço comercial para negócios" });
            }
        }

    }
}